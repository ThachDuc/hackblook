(function(){
    Array.from(document.querySelectorAll("input")).map(n=>n.removeAttribute("maxLength"))
})();
